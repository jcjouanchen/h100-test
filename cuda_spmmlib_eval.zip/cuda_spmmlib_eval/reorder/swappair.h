#ifndef SWAPPAIR_H
#define SWAPPAIR_H

class SwapPair {
public:
    SwapPair(int _v1, int _v2, int lg, int rg) : v1(_v1), v2(_v2), 
    left_gain(lg), right_gain(rg){}

    void print()
    {
       std::cout << "swap (" + std::to_string(v1) + ", " + std::to_string(v2) + "): swap_gain = (" + std::to_string(left_gain) + ", " + std::to_string(right_gain) + ")\n";
    }

public:
    int v1;
    int v2;
    int left_gain;
    int right_gain;
};

// for dequeue
bool funComparator(SwapPair *p1, SwapPair *p2)
{
    if (p1->left_gain+p1->right_gain == p2->left_gain+p2->right_gain) 
    {
        return p1->right_gain >= p2->right_gain;
    }

    return  p1->left_gain+p1->right_gain > p2->left_gain+p2->right_gain;
}

// for priority queue
bool Comparator(SwapPair *p1, SwapPair *p2)
{
    if (p1->left_gain+p1->right_gain == p2->left_gain+p2->right_gain) 
    {
        return p1->right_gain <= p2->right_gain;
    }

    return  p1->left_gain+p1->right_gain < p2->left_gain+p2->right_gain;
}

void showpq(std::priority_queue<SwapPair*, std::vector<SwapPair*>, 
            std::function<bool(SwapPair*, SwapPair*)>> gq)
{
    std::priority_queue<SwapPair*, std::vector<SwapPair*>, std::function<bool(SwapPair*, SwapPair*)>> g = gq;
    while (!g.empty()) {
        (g.top())->print();
        g.pop();
    }
    std::cout << '\n';
}

void showpq(std::priority_queue<std::pair<int, int>, std::vector<std::pair<int, int>>, 
            std::function<bool(std::pair<int, int>&, std::pair<int, int>&)>> gq)
{
    std::priority_queue<std::pair<int, int>, std::vector<std::pair<int, int>>, std::function<bool(std::pair<int, int>&, std::pair<int, int>&)>> g = gq;
    while (!g.empty()) {
        std::cout << (g.top()).first << "(" << (g.top()).second << "), ";
        g.pop();
    }
    std::cout << '\n';
}



#endif