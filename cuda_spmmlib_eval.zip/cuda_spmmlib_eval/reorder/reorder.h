#ifndef REORDER_H
#define REORDER_H

#include "../mtx/Mtx.h"

#include <queue>
#include <functional>
#include "swappair.h"

typedef std::priority_queue<std::pair<int, int>, std::vector<std::pair<int, int>>, std::function<bool(std::pair<int, int>&, std::pair<int, int>&)>> InvalSegList;
typedef std::priority_queue<SwapPair*, std::vector<SwapPair*>, std::function<bool(SwapPair*, SwapPair*)>> SwapPairList;

// A faster way to obtain lane id in a warp
#define GET_LANEID              \
    unsigned laneid;            \
    asm("mov.u32 %0, %%laneid;" \
        : "=r"(laneid));

__global__ void Reorder(int *row, int *col, int *newid, const int nnz)
{
    const int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < nnz)
    {
        int u = row[idx];
        int v = col[idx];
        if (newid[u] != -1) 
            row[idx] = newid[u];
        if (newid[v] != -1) 
            col[idx] = newid[v];
    }
}

// binary search
template <typename Index>
__device__ Index binarySearchInd(const Index *array,
                                 Index target,
                                 Index begin,
                                 Index end)
{
    int mid;
    while (begin < end)
    {
        int mid = begin + (end - begin) / 2;
        int item = array[mid];
        if (item == target)
            return mid;
        bool larger = (item > target);
        if (larger)
            end = mid;
        else
            begin = mid + 1;
    }

    return -1;
}

__device__ void printBits(unsigned char num)
{
    unsigned char j;
    for (j = 1 << 7; j > 0; j = j / 2)
        (num & j) ? printf("1") : printf("0");
    printf("\n");
}

// define profitable swap
__global__ void GetSegSwapScore(int *score, 
                                const int* __restrict__ bsrrowptr, 
                                const int* __restrict__ bsrcolind, 
                                const float* __restrict__ bsrval, 
                                const int nrows, const int seg1, const int seg2)
{
    const int idx = blockIdx.x * blockDim.x + threadIdx.x;
    GET_LANEID;

    if (idx < nrows)
    {
        // retrieve bitmap
        int id1 = binarySearchInd<int>(bsrcolind, seg1, bsrrowptr[idx/M], bsrrowptr[idx/M+1]);
        
        register unsigned lval = 0x00000000;
        if (id1 != -1)
        {
            for (int i=0; i<M; i++) 
                lval = (lval << 1) + (bsrval[id1*M*M+(laneid%M)*M+i] != 0.0f);
        }

        int id2 = binarySearchInd<int>(bsrcolind, seg2, bsrrowptr[idx/M], bsrrowptr[idx/M+1]);
        register unsigned rval = 0x00000000;
        if (id2 != -1)
        {
            for (int i=0; i<M; i++) 
                rval = (rval << 1) + (bsrval[id2*M*M+(laneid%M)*M+i] != 0.0f);
        }

        // examine if swap is profitable 
        // register unsigned gainval = __popc(__ballot_sync(0xFFFFFFFF, (__popc(lval) + __popc(rval)) <= 2N));
        // register unsigned livcnt = __popc((__ballot_sync(0xFFFFFFFF, __popc(lval) > N)));
        // register unsigned rivcnt = __popc((__ballot_sync(0xFFFFFFFF, __popc(rval) > N)));

        // if (laneid == 0) 
        // {
        //     atomicAdd(&score[0], gainval);
        //     atomicAdd(&score[1], livcnt);
        //     atomicAdd(&score[2], rivcnt);
        // }

        // swapping 1 bit between lval and rval
        register int lgain[M*M] = {0};
        register int rgain[M*M] = {0};

        for (int bitpos1=0; bitpos1<M; bitpos1++)
        {
            for (int bitpos2=0; bitpos2<M; bitpos2++)
            {
                unsigned bit1 = (lval >> (M-1-bitpos1)) & 0x1;
                unsigned bit2 = (rval >> (M-1-bitpos2)) & 0x1; 

                register unsigned lval_new = (lval & ~(1 << (M-1-bitpos1))) | (bit2 << (M-1-bitpos1));
                register unsigned rval_new = (rval & ~(1 << (M-1-bitpos2))) | (bit1 << (M-1-bitpos2));
                // if (idx == 3 && bitpos1==0 && bitpos2==0) printBits(rval_new);

                lgain[bitpos1*M+bitpos2] = ((__popc(lval) > N)?1:0) - ((__popc(lval_new) > N)?1:0);  // 1, 0, -1
                rgain[bitpos1*M+bitpos2] = ((__popc(rval) > N)?1:0) - ((__popc(rval_new) > N)?1:0);  // 1, 0, -1
            }
        }

        // store score
        for (int i=0; i<M*M; i++)
        {
            atomicAdd(&score[i*2+0], lgain[i]);
            atomicAdd(&score[i*2+1], rgain[i]);
        }
    }
}

__global__ void LocateinvalidSegment(int *result, 
                                     const int* __restrict__ bsrrowptr, 
                                     const int* __restrict__ bsrcolind, 
                                     const float* __restrict__ bsrval, 
                                     const int nrows, const int num_of_segment)
{
    const int idx = blockIdx.x * blockDim.x + threadIdx.x;
    const int idy = blockIdx.y * blockDim.y + threadIdx.y;
    GET_LANEID;

    if (idx < nrows && idy < num_of_segment)
    {  
        // retrieve bitmap
        int id = binarySearchInd<int>(bsrcolind, idy, bsrrowptr[idx/M], bsrrowptr[idx/M+1]);

        register unsigned val = 0x00000000;
        if (id != -1)
        {
            for (int i=0; i<M; i++) 
                val = (val << 1) + (bsrval[id*M*M+(laneid%M)*M+i] != 0.0f);
        }

        // warp vote to count
        register unsigned ivcnt = __popc((__ballot_sync(0xFFFFFFFF, __popc(val) > N)));
        if (laneid == 0) atomicAdd(&result[idy], ivcnt);
    }

}



template <typename T>
class reorderUtil {
public: 
    reorderUtil(Mtx<T> *_mat, int _maxiter): 
                mat(_mat), MAXITER(_maxiter) {
        
        // init num_of_segment
        num_of_segment = (((mat->nrows) + M - 1) / M);

        // init permute id list
        newid.resize(mat->nrows); 
        memset(&newid[0], -1, (this->mat)->nrows*sizeof(int));

        // init backup coo storage
        SAFE_ALOC_GPU(bckp_coo_row, (this->mat)->nnz*sizeof(int));
        SAFE_ALOC_GPU(bckp_coo_col, (this->mat)->nnz*sizeof(int));
    }
    ~reorderUtil() { 
    }

    // one step commit to newid 
    void swap(const int v1, const int v2) { newid[v1] = v2; newid[v2] = v1;}
    
    // total commit per iteration
    void reorder();

    // new heuristic
    InvalSegList locate_invalid_segment();
    SwapPairList get_segment_swap_score(const int seg1, const int seg2);

    // main reorder function
    bool visited(const int v) { return this->newid[v] != -1; }
    std::vector<int> run(bool verbose);

    // stats
    int get_total_invalid_segment_cnt(InvalSegList isl);

public:
    int MAXITER;
    int EXPLORE_RATE = 1;
    int EXPLOIT_RATE = 1;
    int topN = 1;

    int num_of_segment;

    Mtx<T> *mat;
    std::vector<int> newid;

    // for reorder backtrace
    int *bckp_coo_row;
    int *bckp_coo_col;
};

template<typename T>
void reorderUtil<T>::reorder() 
{
    // backup current coo for backtracing
    CUDA_SAFE_CALL( cudaMemcpy(this->bckp_coo_row, (this->mat)->device_ref.coo_rowind, 
                    (this->mat)->nnz*sizeof(int), cudaMemcpyDeviceToDevice) );
    CUDA_SAFE_CALL( cudaMemcpy(this->bckp_coo_col, (this->mat)->device_ref.coo_colind, 
                    (this->mat)->nnz*sizeof(int), cudaMemcpyDeviceToDevice) );  

    // parallelize to gpu, O(nnz) -> O(1)
    int *newid_gpu;
    SAFE_ALOC_GPU(newid_gpu, (this->mat)->nrows*sizeof(int));
    CUDA_SAFE_CALL( cudaMemcpy(newid_gpu, &this->newid[0], 
                    (this->mat)->nrows*sizeof(int), cudaMemcpyHostToDevice) );  
    dim3 GRID(((this->mat)->nnz+MAXTHRD-1)/MAXTHRD);
    dim3 BLOCK(MAXTHRD);
    Reorder<<<GRID, BLOCK>>>((this->mat)->device_ref.coo_rowind, 
                             (this->mat)->device_ref.coo_colind, 
                             newid_gpu, (this->mat)->nnz);
    SAFE_FREE_GPU(newid_gpu);

    // reset newid
    memset(&this->newid[0], -1, (this->mat)->nrows*sizeof(int));

    // reset matrix
    (this->mat)->reset(); // use coo format to update
}


// sort by decreasing cnt
bool cmp(std::pair<int, int>& a, std::pair<int, int>& b) 
{
    // if cnt are the same, sort by seg ID
    if (a.second == b.second) return a.first > b.first;
    return a.second < b.second; 
} 

template<typename T>
InvalSegList reorderUtil<T>::locate_invalid_segment()
{
    int *result_gpu;
    SAFE_ALOC_GPU(result_gpu, this->num_of_segment*sizeof(int));
    CUDA_SAFE_CALL( cudaMemset(result_gpu, 0, this->num_of_segment*sizeof(int)) );
    
    dim3 GRID(((this->mat)->nrows+MAXTHRD-1)/MAXTHRD, this->num_of_segment);
    dim3 BLOCK(MAXTHRD, 1);
    LocateinvalidSegment<<<GRID, BLOCK>>>(result_gpu, 
                                         (this->mat)->device_ref.bsr_indptr, 
                                         (this->mat)->device_ref.bsr_indices,
                                         (this->mat)->device_ref.bsr_values,
                                         (this->mat)->nrows, this->num_of_segment);

    std::vector<int> result(this->num_of_segment);
    CUDA_SAFE_CALL( cudaMemcpy(&result[0], result_gpu,
                    this->num_of_segment*sizeof(int), cudaMemcpyDeviceToHost) );  
    SAFE_FREE_GPU(result_gpu);

    // std::vector<std::pair<int, int>> invresult;
    // for(int i=0; i<this->num_of_segment; i++) if (result[i] != 0) invresult.push_back({i, result[i]});

    // sort by invalid count
    // std::sort(invresult.begin(), invresult.end(), cmp); 

    InvalSegList invresult(cmp);
    for(int i=0; i<this->num_of_segment; i++) if (result[i] != 0) invresult.push({i, result[i]});

    // showpq(invresult);

    return invresult;
}

template<typename T>
SwapPairList reorderUtil<T>::get_segment_swap_score(const int seg1, const int seg2)
{
    int *result_gpu;
    SAFE_ALOC_GPU(result_gpu, M*M*2*sizeof(int));
    CUDA_SAFE_CALL( cudaMemset(result_gpu, 0, M*M*2*sizeof(int)) );
    
    dim3 GRID(((this->mat)->nrows+MAXTHRD-1)/MAXTHRD);
    dim3 BLOCK(MAXTHRD);
    GetSegSwapScore<<<GRID, BLOCK>>>(result_gpu, 
                                    (this->mat)->device_ref.bsr_indptr, 
                                    (this->mat)->device_ref.bsr_indices,
                                    (this->mat)->device_ref.bsr_values,
                                    (this->mat)->nrows, seg1, seg2);

    std::vector<int> result(M*M*2);
    CUDA_SAFE_CALL( cudaMemcpy(&result[0], result_gpu,
                    M*M*2*sizeof(int), cudaMemcpyDeviceToHost) );  
    SAFE_FREE_GPU(result_gpu);

    // get a 16-by-16 {lgain, rgain}
    // ideally, both linvcnt-lgain & rinvcnt-rgain eqauls to 0
    // if not, we get at best rinvcnt-rgain = 0, then remove R in set
    SwapPairList pq(Comparator);
    for (int i=0; i<M*M; i++)
    {
        int lgain = result[i*2+0], rgain = result[i*2+1];
        // if ((rgain > 0) && (lgain + rgain > 0)) // option1: ensure rgain is positive (target seg's cnt is decreasing)
        // if ((lgain >= 0) && (rgain >= 0) && (lgain + rgain > 0)) // option2: filter out the negative gains
        // option3: don't do any filtering at all
        // {
            SwapPair *p = new SwapPair(seg1*M+(i/M), seg2*M+(i%M), lgain, rgain);
            pq.push(p);
        // }
    }

    return pq;
}

template<typename T>
int reorderUtil<T>::get_total_invalid_segment_cnt(InvalSegList isl)
{
    InvalSegList g = isl;
    int cnt = 0;
    while (!g.empty()) {
        cnt += (g.top()).second;
        g.pop();
    }

    return cnt;
}


template<typename T>
std::vector<int> reorderUtil<T>::run(bool verbose=false) 
{
    InvalSegList inv_seg_list = this->locate_invalid_segment();
    int init_cnt = this->get_total_invalid_segment_cnt(inv_seg_list);
    int primary_seg, primary_cnt, target_seg, target_cnt;
    int round = 1;

    while (inv_seg_list.size() > 1 && round <= MAXITER) {

        if (verbose) { 
            std::cout << "===== Invalid Segment List (round " + std::to_string(round) + ") =====" << std::endl;
            showpq(inv_seg_list);
        }

        // set primary seg & cnt
        primary_seg = inv_seg_list.top().first;
        primary_cnt = inv_seg_list.top().second;
        inv_seg_list.pop();

        if (verbose) { 
            std::cout << "===== primary_seg: " + std::to_string(primary_seg) + \
            ", primary_cnt: " + std::to_string(primary_cnt) + "=====" << std::endl;
        }

        // as primary seg still has invalid segs & not all nodes are visited
        while (primary_cnt > 0 && inv_seg_list.size() >= 1) {

            target_seg = inv_seg_list.top().first;
            target_cnt = inv_seg_list.top().second;

            if (verbose) { 
                std::cout << "===== target_seg: " + std::to_string(target_seg) + \
                ", target_cnt: " + std::to_string(target_cnt) + "=====" << std::endl;
            }

            // retrive swap list
            SwapPairList score = this->get_segment_swap_score(primary_seg, target_seg);
            if (verbose) { 
                std::cout << "===== Swap Pair List =====" << std::endl;
                showpq(score);
            }

            // if lseg's node is visited, pop top
            if (verbose) std::cout << "===== Filter out the visited nodes in list: =====" << std::endl;
            while (!score.empty() && visited((score.top())->v1)) { 
                if (verbose) std::cout << (score.top())->v1 << " has been visited in this round!" << std::endl; 
                score.pop(); 
            }
            
            // otherwise, swap the toppest pair
            if (!score.empty() && !visited((score.top())->v1))
            {
                SwapPair *p = score.top();
                this->swap(p->v1, p->v2);
                primary_cnt -= p->left_gain;
                target_cnt -= p->right_gain;

                if (verbose) {
                    std::cout << "===== ##Swap## =====" << std::endl; 
                    p->print();
                    std::cout << "===== primary_cnt: " + std::to_string(primary_cnt) + \
                    ", target_cnt: " + std::to_string(target_cnt) + "=====" << std::endl;
                }
            }

            // pop target as this iter has done
            // if there's even no pair to swap in this target
            // drop the target and move on
            inv_seg_list.pop();

            // int x; std::cin >> x;
        }

        // reorder
        if (verbose) std::cout << "===== ##Reorder## =====" << std::endl; 
        this->reorder();

        // locate invalid list for new round
        inv_seg_list = this->locate_invalid_segment();

        // for new round
        round += 1;
    } 


    inv_seg_list = this->locate_invalid_segment();
    int final_cnt = this->get_total_invalid_segment_cnt(inv_seg_list);

    if (verbose) { 
        std::cout<< "===== Only 1 or 0 invalid segment left ==> Complete =====" << std::endl;
        showpq(inv_seg_list);
        std::cout<< "===== init_cnt: " << init_cnt << ", final_cnt: " << final_cnt \
        << ", improve_rate: " << (init_cnt-final_cnt)*1.0f/init_cnt << " =====" << std::endl;
    }

    return {init_cnt, final_cnt, round-1};
}

#endif